<?php
/*
Plugin Name: manga importer by ma3och
Description: Import manga and chapters from external sources into WP Manga.
Version: 1.1
Author: ma3och
*/
@set_time_limit(600);

// Include background processing classes
require_once plugin_dir_path(__FILE__) . 'includes/class-manga-background-process.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-manga-importer-status.php';

// Initialize background processes
$manga_background_process = new Manga_Background_Process();
$chapter_background_process = new Chapter_Background_Process();

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include admin pages
require_once plugin_dir_path(__FILE__) . 'admin/background-process-stats.php';

// Add admin menu
add_action('admin_menu', function() {
    add_menu_page(
        'Manga Importer',
        'Manga Importer',
        'manage_options',
        'the-importer-by-ma3och',
        'the_importer_by_kimo_admin_page',
        'dashicons-upload',
        80
    );
    
    add_submenu_page(
        'the-importer-by-ma3och',
        'Background Process Stats',
        'Process Stats',
        'manage_options',
        'the-importer-by-ma3och-stats',
        'the_importer_by_kimo_stats_page'
    );
});

// Admin page content
// Original import functions for backward compatibility
function the_importer_by_kimo_import_manga($url, $chapter_limit = null) {
    return the_importer_by_kimo_import_manga_bg($url, $chapter_limit);
}

function the_importer_by_kimo_import_chapter($chapter_url, $manga_id) {
    return the_importer_by_kimo_import_chapter_bg($chapter_url, $manga_id);
}

// Admin page content
function the_importer_by_kimo_admin_page() {
    // Check if we're viewing a status page
    if (isset($_GET['view_status'])) {
        the_importer_by_kimo_status_page($_GET['view_status']);
        return;
    }
    ?>
    <div class="wrap">
        <h1>Manga Importer by ma3och</h1>
        <div class="notice notice-info"><p>Use this tool to import manga and chapters from external sources. All imports run in the background.</p></div>

        <!-- Import New Manga -->
        <div class="card">
            <form method="post" action="">
                <h2 class="title">Import New Manga</h2>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Manga URL</th>
                    <td><input type="text" name="manga_url" class="regular-text" size="80" value="" placeholder="https://example.com/manga/..." /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">How many chapters to import?</th>
                    <td>
                        <input type="number" name="chapter_limit" min="1" placeholder="Leave blank for all" style="width:100px;" />
                        <span class="description">Leave blank to import all chapters.</span>
                    </td>
                </tr>
            </table>
            <?php submit_button('Import Manga'); ?>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['manga_url'])) {
            global $manga_background_process;
            
            $url = esc_url_raw($_POST['manga_url']);
            $chapter_limit = isset($_POST['chapter_limit']) && is_numeric($_POST['chapter_limit']) ? intval($_POST['chapter_limit']) : null;
            
            // Create status entry
            $hash = Manga_Importer_Status::create_status('manga', $url, [
                'chapter_limit' => $chapter_limit
            ]);
            
            // Add to background process queue
            $manga_background_process->push_to_queue([
                'manga_url' => $url,
                'chapter_limit' => $chapter_limit,
                'hash' => $hash
            ])->save()->dispatch();
            
            echo '<h2>Importing from: ' . esc_html($url) . '</h2>';
            echo '<div class="notice notice-success is-dismissible"><p>✅ Manga import has been queued for background processing. <a href="#" class="view-progress-link">View progress</a></p></div>';
            echo '<p><a href="' . admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash) . '" class="button">View Import Status</a></p>';
        }
        ?>

        <hr>

        <!-- Add chapters to existing manga -->
        <div class="card">
            <form method="post" action="">
                <h2 class="title">Add Chapter(s) to Existing Manga</h2>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Select Manga</th>
                    <td>
                        <select name="existing_manga_id">
                            <option value="">-- Select Manga --</option>
                            <?php
                            $mangas = get_posts(array(
                                'post_type' => 'wp-manga',
                                'numberposts' => -1,
                                'post_status' => 'publish',
                                'orderby' => 'title',
                                'order' => 'ASC'
                            ));
                            foreach ($mangas as $manga) {
                                echo '<option value="' . esc_attr($manga->ID) . '">' . esc_html($manga->post_title) . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Chapter URLs (one per line)</th>
                    <td><textarea name="chapter_urls" class="large-text code" rows="5" cols="80" placeholder="https://example.com/chapter/1\nhttps://example.com/chapter/2"></textarea></td>
                </tr>
            </table>
            <?php submit_button('Add Chapter(s)'); ?>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['existing_manga_id']) && !empty($_POST['chapter_urls'])) {
            global $chapter_background_process;
            
            $manga_id = intval($_POST['existing_manga_id']);
            $chapter_urls = explode("\n", trim($_POST['chapter_urls']));
            echo '<h2>Adding chapters to manga ID: ' . intval($manga_id) . '</h2>';
            
            $queued_chapters = 0;
            $status_links = [];
            
            foreach ($chapter_urls as $chapter_url) {
                $chapter_url = trim($chapter_url);
                if (!empty($chapter_url)) {
                    // Create status entry
                    $hash = Manga_Importer_Status::create_status('chapter', $chapter_url, [
                        'manga_id' => $manga_id,
                        'chapter_url' => $chapter_url
                    ]);
                    
                    // Add to background process queue
                    $chapter_background_process->push_to_queue([
                        'chapter_url' => $chapter_url,
                        'manga_id' => $manga_id,
                        'hash' => $hash
                    ]);
                    
                    $status_links[] = '<a href="' . admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash) . '">Chapter ' . ($queued_chapters + 1) . '</a>';
                    $queued_chapters++;
                }
            }
            
            if ($queued_chapters > 0) {
                $chapter_background_process->save()->dispatch();
                echo '<div class="notice notice-success"><p>' . $queued_chapters . ' chapter(s) have been queued for background processing.</p></div>';
                
                if (!empty($status_links)) {
                    echo '<p>View status: ' . implode(' | ', $status_links) . '</p>';
                }
            }
        }
        ?>
    </div>
    <?php
}

// Background version of the import function
function the_importer_by_kimo_import_manga_bg($url, $chapter_limit = null, $hash = null, $force_import = false) {
    $response = wp_remote_get($url, array(
        'headers' => array(
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
        )
    ));

    if (is_wp_error($response)) {
        echo '<p>Error fetching manga page: ' . esc_html($response->get_error_message()) . '</p>';
        return;
    }

    $body = wp_remote_retrieve_body($response);
    if (!$body) {
        echo '<p>Empty response from manga page.</p>';
        return;
    }

    libxml_use_internal_errors(true);
    $doc = new DOMDocument();
    $doc->loadHTML($body);
    libxml_clear_errors();

    $xpath = new DOMXPath($doc);

    // Extract title
    $titleNode = $xpath->query("//div[contains(@class,'post-title')]//h1");
    $title = $titleNode->length ? trim($titleNode->item(0)->nodeValue) : 'Untitled Manga';

    echo '<p><strong>Title:</strong> ' . esc_html($title) . '</p>';
    
    // Extract alternative title
    $alt_title = '';
    $altTitleLabelNode = $xpath->query("//h5[contains(text(),'Alternative')]");
    if ($altTitleLabelNode->length) {
        $altTitleNode = $xpath->query("//h5[contains(text(),'Alternative')]/following-sibling::div[1]");
        if ($altTitleNode->length) {
            $alt_title = trim($altTitleNode->item(0)->nodeValue);
            echo '<p><strong>Alternative Title:</strong> ' . esc_html($alt_title) . '</p>';
        }
    }

    // Extract cover image
    // Try multiple XPath queries for cover image
    $cover_url = '';
    
    // First try: Original location
    $coverNode = $xpath->query("//div[contains(@class,'summary_image')]//img");
    if ($coverNode->length) {
        $cover_url = $coverNode->item(0)->hasAttribute('data-src') 
            ? $coverNode->item(0)->getAttribute('data-src')
            : $coverNode->item(0)->getAttribute('src');
    }
    
    // Second try: Common chapter page location
    if (empty($cover_url)) {
        $coverNode = $xpath->query("//div[contains(@class,'post-content')]//img");
        if ($coverNode->length) {
            $cover_url = $coverNode->item(0)->hasAttribute('data-src') 
                ? $coverNode->item(0)->getAttribute('data-src')
                : $coverNode->item(0)->getAttribute('src');
        }
    }
    
    // Third try: Main page location (if available)
    if (empty($cover_url)) {
        $coverNode = $xpath->query("//div[contains(@class,'tab-summary')]//img");
        if ($coverNode->length) {
            $cover_url = $coverNode->item(0)->hasAttribute('data-src') 
                ? $coverNode->item(0)->getAttribute('data-src')
                : $coverNode->item(0)->getAttribute('src');
        }
    }
    
    // Final fallback: Try any img with 'cover' in class
    if (empty($cover_url)) {
        $coverNode = $xpath->query("//img[contains(@class,'cover')]");
        if ($coverNode->length) {
            $cover_url = $coverNode->item(0)->hasAttribute('data-src') 
                ? $coverNode->item(0)->getAttribute('data-src')
                : $coverNode->item(0)->getAttribute('src');
        }
    }

    echo '<p><strong>Cover Image URL:</strong> ' . esc_url($cover_url) . '</p>';

    // Extract description
    $descNode = $xpath->query("//div[contains(@class,'description-summary')]//div[contains(@class,'summary__content')]");
    $description = $descNode->length ? trim($descNode->item(0)->nodeValue) : '';

    echo '<p><strong>Description:</strong> ' . esc_html($description) . '</p>';
    
    // Extract genres
    $genres = array();
    $genresNode = $xpath->query("//div[contains(@class,'genres-content')]/a");
    if ($genresNode->length) {
        foreach ($genresNode as $genre) {
            $genres[] = trim($genre->nodeValue);
        }
        echo '<p><strong>Genres:</strong> ' . esc_html(implode(', ', $genres)) . '</p>';
    }
    
    // Check for existing manga with the same title
    $existing_manga_id = null;
    $exact_match = false;
    
    // First, try to find an exact match by title
    $exact_matches = get_posts(array(
        'post_type' => 'wp-manga',
        'post_status' => 'publish',
        'title' => $title,
        'posts_per_page' => 1,
        'exact' => true
    ));
    
    if (!empty($exact_matches)) {
        $existing_manga_id = $exact_matches[0]->ID;
        $exact_match = true;
        echo '<p><strong>Found existing manga with exact title match:</strong> ' . esc_html($title) . ' (ID: ' . $existing_manga_id . ')</p>';
    }
    
    // If no exact match and not forcing import, check for similar titles
    if (!$exact_match && !$force_import) {
        $similar_mangas = get_posts(array(
            'post_type' => 'wp-manga',
            'post_status' => 'publish',
            's' => $title,
            'posts_per_page' => 5
        ));
        
        if (!empty($similar_mangas)) {
            echo '<p><strong>Warning: Similar manga title(s) found:</strong></p>';
            echo '<ul>';
            foreach ($similar_mangas as $similar) {
                echo '<li>' . esc_html($similar->post_title) . ' (ID: ' . $similar->ID . ')</li>';
            }
            echo '</ul>';
            
            // If we have a hash, update the status to pending
            if ($hash) {
                Manga_Importer_Status::update_status('manga', $hash, [
                    'status' => 'pending',
                    'similar_titles' => array_map(function($manga) {
                        return ['id' => $manga->ID, 'title' => $manga->post_title];
                    }, $similar_mangas),
                    'manga_data' => [
                        'title' => $title,
                        'alt_title' => $alt_title,
                        'description' => $description,
                        'cover_url' => $cover_url,
                        'url' => $url,
                        'chapter_limit' => $chapter_limit,
                        'genres' => $genres
                    ]
                ]);
                
                echo '<p>Import status set to <strong>pending</strong>. Please review and approve or cancel the import.</p>';
                return null; // Return null to indicate pending status
            }
            
            // If no hash (direct function call), ask for confirmation
            echo '<p>Please check if this is a duplicate before proceeding.</p>';
        }
    }
    
    // Use existing manga if found, otherwise create a new one
    if ($exact_match && $existing_manga_id) {
        $manga_id = $existing_manga_id;
        echo '<p>Using existing manga with ID: ' . intval($manga_id) . '</p>';
    } else {
        // Create manga post
        $manga_post = array(
            'post_title'    => wp_strip_all_tags($title),
            'post_content'  => $description,
            'post_status'   => 'publish',
            'post_type'     => 'wp-manga',
        );

        $manga_id = wp_insert_post($manga_post);
    }

    if (is_wp_error($manga_id) || !$manga_id) {
        echo '<p>Error creating/accessing manga post.</p>';
        return;
    }

    // Check if this is a new manga or existing one
    if (!$exact_match) {
        // Generate unique manga ID using Madara Core's format for new manga
        $uniqid = 'manga_' . substr(md5($manga_id), 0, 8);
        update_post_meta($manga_id, 'manga_unique_id', $uniqid);
        echo '<p>Manga post created with ID: ' . intval($manga_id) . '</p>';
        
        // Set default chapter type for this manga
        update_post_meta($manga_id, '_wp_manga_chapter_type', 'manga');
        
        // Set alternative title if available
        if (!empty($alt_title)) {
            update_post_meta($manga_id, '_wp_manga_alternative', $alt_title);
            echo '<p>Alternative title saved: ' . esc_html($alt_title) . '</p>';
        }
        
        // Set genres as taxonomy terms
        if (!empty($genres)) {
            foreach ($genres as $genre) {
                wp_set_object_terms($manga_id, $genre, 'wp-manga-genre', true);
            }
            echo '<p>' . count($genres) . ' genres added to manga.</p>';
        }

        // Set cover image as featured image
        if ($cover_url) {
            $attachment_id = the_importer_by_kimo_upload_image($cover_url, $manga_id);
            if ($attachment_id) {
                set_post_thumbnail($manga_id, $attachment_id);
                echo '<p>Cover image set as featured image.</p>';
            }
        }
    } else {
        // For existing manga, update metadata if needed
        echo '<p>Using existing manga. Checking for metadata updates...</p>';
        
        // Update alternative title if available and different
        if (!empty($alt_title)) {
            $existing_alt_title = get_post_meta($manga_id, '_wp_manga_alternative', true);
            if ($existing_alt_title !== $alt_title) {
                update_post_meta($manga_id, '_wp_manga_alternative', $alt_title);
                echo '<p>Alternative title updated: ' . esc_html($alt_title) . '</p>';
            }
        }
        
        // Add any new genres
        if (!empty($genres)) {
            foreach ($genres as $genre) {
                wp_set_object_terms($manga_id, $genre, 'wp-manga-genre', true);
            }
            echo '<p>Genres updated for manga.</p>';
        }
        
        // Only update cover if it doesn't have one
        if ($cover_url && !has_post_thumbnail($manga_id)) {
            $attachment_id = the_importer_by_kimo_upload_image($cover_url, $manga_id);
            if ($attachment_id) {
                set_post_thumbnail($manga_id, $attachment_id);
                echo '<p>Cover image set as featured image.</p>';
            }
        }
    }

    // Extract chapter links
    $chapter_links = [];
    $chapterListNode = $xpath->query("//ul[contains(@class,'main') and contains(@class,'version-chap')]");
    if ($chapterListNode->length) {
        $lis = $chapterListNode->item(0)->getElementsByTagName('li');
        foreach ($lis as $li) {
            $a = $li->getElementsByTagName('a')->item(0);
            if ($a) {
                $href = $a->getAttribute('href');
                $chapter_links[] = $href;
            }
        }
    }

    echo '<p>Found ' . count($chapter_links) . ' chapters.</p>';

    // Limit chapters if requested
    $chapter_links = array_reverse($chapter_links);
    if ($chapter_limit !== null && $chapter_limit > 0) {
        $chapter_links = array_slice($chapter_links, 0, $chapter_limit);
        echo '<p>Importing only the first ' . intval($chapter_limit) . ' chapters.</p>';
    }

    // Import chapters
    // If we have a hash, track chapters for resuming
    if ($hash) {
        // Check if we already have tracked chapters
        $tracked_chapters = Manga_Importer_Status::get_manga_chapters($hash);
        
        // Track all chapters if not already tracked
        if (!$tracked_chapters) {
            foreach ($chapter_links as $chapter_url) {
                $chapter_hash = md5($chapter_url);
                Manga_Importer_Status::track_chapter_in_manga($hash, $chapter_url, $chapter_hash);
            }
        }
        
        // Get updated tracked chapters
        $tracked_chapters = Manga_Importer_Status::get_manga_chapters($hash);
        
        // Process chapters based on their status
        foreach ($chapter_links as $chapter_url) {
            // Skip already completed chapters
            if (isset($tracked_chapters[$chapter_url]) && $tracked_chapters[$chapter_url]['status'] === 'completed') {
                echo '<hr><p>Chapter already imported: ' . esc_url($chapter_url) . '</p>';
                continue;
            }
            
            echo '<hr><p>Importing chapter: ' . esc_url($chapter_url) . '</p>';
            
            // Update chapter status to processing
            if (isset($tracked_chapters[$chapter_url])) {
                Manga_Importer_Status::update_chapter_in_manga($hash, $chapter_url, 'processing');
            }
            
            // Import the chapter
            $result = the_importer_by_kimo_import_chapter($chapter_url, $manga_id);
            
            // Update chapter status based on result
            if (isset($tracked_chapters[$chapter_url])) {
                $status = $result ? 'completed' : 'failed';
                Manga_Importer_Status::update_chapter_in_manga($hash, $chapter_url, $status);
            }
        }
    } else {
        // Legacy mode without tracking (for backward compatibility)
        foreach ($chapter_links as $chapter_url) {
            echo '<hr><p>Importing chapter: ' . esc_url($chapter_url) . '</p>';
            the_importer_by_kimo_import_chapter($chapter_url, $manga_id);
        }
    }
    
    // Return the manga ID for tracking in the background process
    return $manga_id;
}

// Upload image from URL and attach to post
function the_importer_by_kimo_upload_image($image_url, $post_id) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $tmp = download_url($image_url);

    if (is_wp_error($tmp)) {
        return false;
    }

    $file_array = array(
        'name'     => basename(parse_url($image_url, PHP_URL_PATH)),
        'tmp_name' => $tmp
    );

    $id = media_handle_sideload($file_array, $post_id);

    if (is_wp_error($id)) {
        @unlink($tmp);
        return false;
    }

    return $id;
}

// Background version of the chapter import function
function the_importer_by_kimo_import_chapter_bg($chapter_url, $manga_id) {
    $response = wp_remote_get($chapter_url, array(
        'headers' => array(
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
        )
    ));

    if (is_wp_error($response)) {
        echo '<p>Error fetching chapter page: ' . esc_html($response->get_error_message()) . '</p>';
        return;
    }

    $body = wp_remote_retrieve_body($response);
    if (!$body) {
        echo '<p>Empty response from chapter page.</p>';
        return;
    }

    libxml_use_internal_errors(true);
    $doc = new DOMDocument();
    $doc->loadHTML($body);
    libxml_clear_errors();

    $xpath = new DOMXPath($doc);

    // Extract images with multiple fallback queries
    $images = [];
    
    // First try: Original query
    $imgNodes = $xpath->query("//img[contains(@class,'wp-manga-chapter-img')]");
    
    // Second try: Common chapter page image containers
    if (!$imgNodes->length) {
        $imgNodes = $xpath->query("//div[contains(@class,'reading-content')]//img");
    }
    
    // Third try: Any img with 'chapter-image' in class
    if (!$imgNodes->length) {
        $imgNodes = $xpath->query("//img[contains(@class,'chapter-image')]");
    }
    
    // Fourth try: Any img in main content area
    if (!$imgNodes->length) {
        $imgNodes = $xpath->query("//div[contains(@class,'entry-content')]//img");
    }
    
    if ($imgNodes->length) {
        foreach ($imgNodes as $img) {
            $src = $img->hasAttribute('data-src') 
                ? $img->getAttribute('data-src')
                : $img->getAttribute('src');
            
            if ($src) {
                $images[] = $src;
            }
        }
    }

    echo '<p>Found ' . count($images) . ' images in chapter.</p>';

    // Get chapter title
    $chapter_title = the_importer_by_kimo_get_chapter_name($chapter_url);
    
    // Check if this chapter already exists for this manga
    $existing_chapters = get_posts(array(
        'post_type' => 'wp-manga-chapter',
        'post_parent' => $manga_id,
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'title' => $chapter_title,
        'exact' => true
    ));
    
    if (!empty($existing_chapters)) {
        echo '<p><strong>Chapter "' . esc_html($chapter_title) . '" already exists for this manga.</strong> Skipping import.</p>';
        return true; // Return true to indicate success (chapter exists)
    }
    
    // Create chapter post
    $chapter_post = array(
        'post_title'    => $chapter_title,
        'post_content'  => '',
        'post_status'   => 'publish',
        'post_type'     => 'wp-manga-chapter',
        'post_parent'   => $manga_id,
    );

    $chapter_id = wp_insert_post($chapter_post);

    if (is_wp_error($chapter_id) || !$chapter_id) {
        echo '<p>Error creating chapter post.</p>';
        return;
    }

    echo '<p>Chapter post created with ID: ' . intval($chapter_id) . '</p>';

    // Set Madara chapter meta for storage, volume, etc.
    update_post_meta($chapter_id, '_wp_manga_chapter_storage', 'local');
    update_post_meta($chapter_id, '_wp_manga_chapter_volume', 0);
    update_post_meta($chapter_id, '_wp_manga_chapter_type', 'manga');

    // Download images to temp folder
    $upload_dir = wp_upload_dir();
    $base_dir = trailingslashit($upload_dir['basedir']);

    // Check for existing Madara manga folder
    $madara_data_dir = $base_dir . 'WP-manga/data/';
    wp_mkdir_p($madara_data_dir);

    // Get manga unique ID from post meta
    $manga_unique_id = get_post_meta($manga_id, 'manga_unique_id', true);
    if (!$manga_unique_id) {
        $manga_unique_id = 'manga_' . substr(md5($manga_id), 0, 8);
    }

    // Create manga folder with unique ID
    $manga_hash_folder = $madara_data_dir . $manga_unique_id;
    wp_mkdir_p($manga_hash_folder);

    $manga_dir = trailingslashit($manga_hash_folder);

    // Create a unique chapter folder (hash) for this chapter
    $chapter_hash = md5($chapter_id . time());
    $chapter_dir = $manga_dir . $chapter_hash . '/';
    wp_mkdir_p($chapter_dir);

    $image_files = array();
    $count = 1;
    foreach ($images as $img_url) {
        $ext = pathinfo(parse_url($img_url, PHP_URL_PATH), PATHINFO_EXTENSION);
        if (!$ext) $ext = 'jpg';
        $filename = sprintf('%03d.%s', $count, $ext);
        $filepath = trailingslashit($chapter_dir) . $filename;

        $response = wp_remote_get($img_url, array('timeout' => 60));
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
            $body = wp_remote_retrieve_body($response);
            file_put_contents($filepath, $body);
            $image_files[] = $filepath;
            $count++;
        }
    }



    // Set Madara zip meta key to relative path
    $relative_zip_path = str_replace($base_dir, '', $chapter_zip_path);
    update_post_meta($chapter_id, '_wp_manga_chapter_zip', $relative_zip_path);

    // Prepare chapter images data JSON
    $chapter_data = array();
    $manga_hash = basename(dirname(rtrim($manga_dir, '/')));
    $chapter_hash = basename($chapter_dir);
    foreach ($image_files as $index => $file_path) {
        $filename = basename($file_path);
        // Use sequential numbering for filenames (1.jpg, 2.jpg, etc.) instead of 001.webp format
        $numbered_filename = ($index + 1) . '.' . pathinfo($filename, PATHINFO_EXTENSION);
        // Rename the file to match the expected format
        $new_filepath = trailingslashit($chapter_dir) . $numbered_filename;
        if (file_exists($file_path) && $file_path !== $new_filepath) {
            rename($file_path, $new_filepath);
            $file_path = $new_filepath;
        }
        $chapter_data[$index + 1] = array(
            'src' => $manga_hash . '/' . $chapter_hash . '/' . $numbered_filename,
            'mime' => false
        );
    }

    // Instead of using AJAX, we'll use the Madara API directly
    // This is more reliable as it uses the internal functions
    
    global $wp_manga_storage, $wp_manga_chapter;
    
    // Create chapter directly using Madara's functions
    $chapter_args = array(
        'post_id'             => $manga_id,
        'volume_id'           => '0', // Default volume
        'chapter_name'        => $chapter_title,
        'chapter_name_extend' => '',
        'chapter_slug'        => sanitize_title($chapter_title),
        'chapter_metas'       => array('uid' => basename($chapter_dir))
    );
    
    // Get manga unique ID
    global $wp_manga;
    $uniqid = $wp_manga->get_uniqid($manga_id);
    
    // Use the existing chapter directory we created
    $extract = $chapter_dir;
    $extract_uri = str_replace(ABSPATH, site_url('/'), $chapter_dir);
    
    // Prepare the image files for Madara's API
    // Rename files to sequential numbers (1.jpg, 2.jpg, etc.) as expected by Madara
    $renamed_files = array();
    foreach ($image_files as $index => $file_path) {
        $ext = pathinfo($file_path, PATHINFO_EXTENSION);
        $new_filename = ($index + 1) . '.' . $ext;
        $new_filepath = trailingslashit($chapter_dir) . $new_filename;
        
        // Rename the file to match Madara's expected format
        if (file_exists($file_path) && $file_path !== $new_filepath) {
            rename($file_path, $new_filepath);
            $renamed_files[] = $new_filepath;
        } else {
            $renamed_files[] = $file_path;
        }
    }
    
    echo '<p>Creating chapter using Madara API...</p>';
    echo '<p>Chapter args: ' . esc_html(json_encode($chapter_args)) . '</p>';
    echo '<p>Extract path: ' . esc_html($extract) . '</p>';
    
    // Create the chapter using Madara's storage function
    $chapter_id = $wp_manga_storage->wp_manga_upload_single_chapter(
        $chapter_args,
        $extract,
        $extract_uri,
        'local',  // Storage type
        false     // Don't overwrite
    );
    
    // Check if chapter creation was successful
    if (is_wp_error($chapter_id)) {
        echo '<p style="color:red;">Error creating chapter: ' . esc_html($chapter_id->get_error_message()) . '</p>';
        return false;
    } elseif (empty($chapter_id)) {
        echo '<p style="color:red;">Failed to create chapter. No chapter ID returned.</p>';
        return false;
    } else {
        echo '<p style="color:lime;">Chapter "' . esc_html($chapter_title) . '" created successfully with ID: ' . intval($chapter_id) . '</p>';
        
        return true;
    }
    
    // If we reach here, something went wrong
    return false;
}

// Generate chapter name from URL
function the_importer_by_kimo_get_chapter_name($url) {
    if (preg_match('/chapter-([\w-]+)/', $url, $matches)) {
        return 'Chapter ' . $matches[1];
    }
    return 'Chapter';
}

// Status page for viewing import progress
function the_importer_by_kimo_status_page($hash) {
    // Start output buffering to prevent 'headers already sent' errors
    ob_start();
    
    // Handle approval or rejection actions first, before any output
    if (isset($_POST['action']) && isset($_POST['hash']) && $_POST['hash'] === $hash) {
        if ($_POST['action'] === 'approve_manga') {
            // Get the manga data from the status
            $log = Manga_Importer_Status::get_status($hash);
            if ($log && $log['status'] === 'pending' && isset($log['manga_data'])) {
                global $manga_background_process;
                
                // Add to background process queue with force_import flag
                $manga_background_process->push_to_queue([
                    'manga_url' => $log['manga_data']['url'],
                    'chapter_limit' => $log['manga_data']['chapter_limit'],
                    'hash' => $hash,
                    'force_import' => true // Force import even if similar titles exist
                ])->save()->dispatch();
                
                // Update status to processing
                Manga_Importer_Status::update_status('manga', $hash, [
                    'status' => 'processing',
                    'approved_at' => current_time('mysql')
                ]);
                
                // Redirect to refresh the page - ensure no output has occurred before this
                wp_safe_redirect(admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash));
                exit;
            }
        } elseif ($_POST['action'] === 'reject_manga') {
            // Update status to rejected
            Manga_Importer_Status::update_status('manga', $hash, [
                'status' => 'rejected',
                'rejected_at' => current_time('mysql')
            ]);
            
            // Redirect to refresh the page - ensure no output has occurred before this
            wp_safe_redirect(admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash));
            exit;
        } elseif ($_POST['action'] === 'restart_manga_import') {
            // Get the manga data from the status
            $log = Manga_Importer_Status::get_status($hash);
            if ($log && isset($log['manga_id'])) {
                global $manga_background_process;
                
                // Add to background process queue to resume import
                $manga_background_process->push_to_queue([
                    'manga_url' => $log['url'],
                    'chapter_limit' => isset($log['chapter_limit']) ? $log['chapter_limit'] : null,
                    'hash' => $hash,
                    'force_import' => false
                ])->save()->dispatch();
                
                // Update status to processing
                Manga_Importer_Status::update_status('manga', $hash, [
                    'status' => 'processing',
                    'restarted_at' => current_time('mysql')
                ]);
                
                // Redirect to refresh the page
                wp_safe_redirect(admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash));
                exit;
            }
        } elseif ($_POST['action'] === 'retry_failed_chapter' && isset($_POST['chapter_url'])) {
            // Get the manga data from the status
            $log = Manga_Importer_Status::get_status($hash);
            if ($log && isset($log['manga_id']) && isset($log['chapters'][$_POST['chapter_url']])) {
                global $chapter_background_process;
                
                $chapter_url = $_POST['chapter_url'];
                $manga_id = $log['manga_id'];
                $chapter_hash = $log['chapters'][$chapter_url]['hash'];
                
                // Add to chapter background process queue
                $chapter_background_process->push_to_queue([
                    'chapter_url' => $chapter_url,
                    'manga_id' => $manga_id,
                    'hash' => $chapter_hash
                ])->save()->dispatch();
                
                // Update chapter status to processing
                Manga_Importer_Status::update_chapter_in_manga($hash, $chapter_url, 'processing');
                
                // Redirect to refresh the page
                wp_safe_redirect(admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash));
                exit;
            }
        }
    }
    
    $log = Manga_Importer_Status::get_status($hash);
    
    if (!$log) {
        wp_die('Import status not found.');
    }
    
    // Determine if this is a manga or chapter import
    $type = isset($log['chapter_url']) ? 'chapter' : 'manga';
    
    // Add scripts for AJAX status updates
    wp_enqueue_script('jquery');
    
    ?>
    <div class="wrap">
        <h1>Import Status</h1>
        <p><a href="<?php echo admin_url('admin.php?page=the-importer-by-ma3och'); ?>" class="button">← Back to Importer</a></p>
        
        <div class="card" id="status-card">
            <h2>Status: <span id="status-text"><?php echo ucfirst($log['status']); ?></span></h2>
            
            <?php if ($log['status'] === 'processing'): ?>
                <p>Started at: <?php echo $log['started_at']; ?></p>
                <p>The import is currently running in the background.</p>
                <div class="spinner is-active" style="float:none; margin:0; margin-right:10px;"></div>
                <span id="status-message">Processing...</span>
            <?php elseif ($log['status'] === 'completed'): ?>
                <p>Completed at: <?php echo $log['completed_at']; ?></p>
                <?php if (isset($log['manga_id'])): ?>
                    <p>Manga ID: <?php echo $log['manga_id']; ?></p>
                    <p><a href="<?php echo get_edit_post_link($log['manga_id']); ?>" class="button">View Manga</a></p>
                    
                    <?php 
                    // Display chapter progress for manga imports
                    if ($type === 'manga' && isset($log['chapters']) && !empty($log['chapters'])): 
                        $total_chapters = count($log['chapters']);
                        $completed_chapters = 0;
                        $failed_chapters = 0;
                        $pending_chapters = 0;
                        
                        foreach ($log['chapters'] as $chapter) {
                            if ($chapter['status'] === 'completed') {
                                $completed_chapters++;
                            } elseif ($chapter['status'] === 'failed') {
                                $failed_chapters++;
                            } else {
                                $pending_chapters++;
                            }
                        }
                    ?>
                    <div class="card" style="margin-top: 20px;">
                        <h3>Chapter Import Progress</h3>
                        <p>
                            <strong>Total Chapters:</strong> <?php echo $total_chapters; ?><br>
                            <strong>Completed:</strong> <?php echo $completed_chapters; ?><br>
                            <strong>Failed:</strong> <?php echo $failed_chapters; ?><br>
                            <strong>Pending/Processing:</strong> <?php echo $pending_chapters; ?>
                        </p>
                        
                        <?php if ($pending_chapters > 0 || $failed_chapters > 0): ?>
                            <div style="margin: 10px 0;">
                                <?php if ($log['status'] === 'completed'): ?>
                                    <form method="post" action="" style="display: inline-block;">
                                        <input type="hidden" name="action" value="restart_manga_import">
                                        <input type="hidden" name="hash" value="<?php echo $hash; ?>">
                                        <button type="submit" class="button button-primary">Restart Import Process</button>
                                    </form>
                                    <p><em>Note: Restarting will continue from where it left off, only processing pending and failed chapters.</em></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        
                        <div style="margin-top: 10px;">
                            <h4>Chapter Details</h4>
                            <table class="widefat">
                                <thead>
                                    <tr>
                                        <th>Chapter URL</th>
                                        <th>Status</th>
                                        <th>Time</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($log['chapters'] as $url => $chapter): ?>
                                    <tr>
                                        <td><?php echo esc_url($url); ?></td>
                                        <td>
                                            <?php 
                                            if ($chapter['status'] === 'completed') {
                                                echo '<span style="color:green;">Completed</span>';
                                            } elseif ($chapter['status'] === 'failed') {
                                                echo '<span style="color:red;">Failed</span>';
                                            } elseif ($chapter['status'] === 'processing') {
                                                echo '<span style="color:blue;">Processing</span>';
                                            } else {
                                                echo '<span style="color:orange;">Pending</span>';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <?php 
                                            if (isset($chapter['completed_at'])) {
                                                echo esc_html(human_time_diff(strtotime($chapter['completed_at']), current_time('timestamp'))) . ' ago';
                                            } elseif (isset($chapter['failed_at'])) {
                                                echo esc_html(human_time_diff(strtotime($chapter['failed_at']), current_time('timestamp'))) . ' ago';
                                            } elseif (isset($chapter['added_at'])) {
                                                echo esc_html(human_time_diff(strtotime($chapter['added_at']), current_time('timestamp'))) . ' ago';
                                            } else {
                                                echo 'N/A';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <?php if ($chapter['status'] === 'failed' && $log['status'] === 'completed'): ?>
                                                <form method="post" action="" style="display: inline-block;">
                                                    <input type="hidden" name="action" value="retry_failed_chapter">
                                                    <input type="hidden" name="hash" value="<?php echo $hash; ?>">
                                                    <input type="hidden" name="chapter_url" value="<?php echo esc_attr($url); ?>">
                                                    <button type="submit" class="button button-small">Retry</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php elseif ($log['status'] === 'pending'): ?>
                <p>Started at: <?php echo $log['started_at']; ?></p>
                <p><strong>This import is pending approval because similar manga titles were found:</strong></p>
                
                <?php if (isset($log['similar_titles']) && !empty($log['similar_titles'])): ?>
                    <table class="widefat" style="margin-bottom: 15px;">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($log['similar_titles'] as $similar): ?>
                                <tr>
                                    <td><?php echo $similar['id']; ?></td>
                                    <td><?php echo esc_html($similar['title']); ?></td>
                                    <td><a href="<?php echo get_edit_post_link($similar['id']); ?>" target="_blank" class="button button-small">View</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                
                <p><strong>New manga to import:</strong> <?php echo isset($log['manga_data']['title']) ? esc_html($log['manga_data']['title']) : 'Unknown'; ?></p>
                
                <form method="post" style="margin-top: 15px;">
                    <input type="hidden" name="hash" value="<?php echo $hash; ?>">
                    <button type="submit" name="action" value="approve_manga" class="button button-primary">Approve Import</button>
                    <button type="submit" name="action" value="reject_manga" class="button">Reject Import</button>
                </form>
            <?php elseif ($log['status'] === 'rejected'): ?>
                <p>Rejected at: <?php echo $log['rejected_at']; ?></p>
                <p>This import was rejected due to similar manga titles.</p>
                <form method="post">
                    <input type="hidden" name="hash" value="<?php echo $hash; ?>">
                    <button type="submit" name="action" value="approve_manga" class="button">Approve Anyway</button>
                </form>
            <?php endif; ?>
        </div>
        </div>
        
        <div id="log-output" <?php echo empty($log['output']) ? 'style="display:none;"' : ''; ?>>
            <h2>Import Log</h2>
            <div style="max-height:400px; overflow:auto; background:#111; color:#0f0; padding:10px; font-family:monospace; font-size:13px;" id="log-content">
                <?php echo !empty($log['output']) ? $log['output'] : ''; ?>
            </div>
        </div>
        
        <?php if ($log['status'] === 'processing'): ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Function to check status
            function checkStatus() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'check_<?php echo $type; ?>_import_status',
                        hash: '<?php echo $hash; ?>',
                        nonce: '<?php echo wp_create_nonce('manga_importer_status'); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data) {
                            // Update status
                            $('#status-text').text(response.data.status.charAt(0).toUpperCase() + response.data.status.slice(1));
                            
                            // Update log output if available
                            if (response.data.output && response.data.output.length > 0) {
                                $('#log-content').html(response.data.output);
                                $('#log-output').show();
                            }
                            
                            // If completed, refresh the page to show all completed info
                            if (response.data.status === 'completed') {
                                location.reload();
                            } else {
                                // Check again in 5 seconds
                                setTimeout(checkStatus, 5000);
                            }
                        } else {
                            // Error occurred, try again in 10 seconds
                            setTimeout(checkStatus, 10000);
                        }
                    },
                    error: function() {
                        // Error occurred, try again in 10 seconds
                        setTimeout(checkStatus, 10000);
                    }
                });
            }
            
            // Start checking status
            setTimeout(checkStatus, 5000);
        });
        </script>
        <?php endif; ?>
    </div>
    <?php
}

