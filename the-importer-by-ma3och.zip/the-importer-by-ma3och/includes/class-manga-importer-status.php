<?php
/**
 * Status Handler for Manga Importer
 *
 * @package The_Importer_By_Kimo
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Manga_Importer_Status Class
 * Handles status tracking and logging for background imports
 */
class Manga_Importer_Status {

    /**
     * Initialize the status handler
     */
    public static function init() {
        // Add AJAX handlers for status updates
        add_action('wp_ajax_check_manga_import_status', array(__CLASS__, 'ajax_check_manga_import_status'));
        add_action('wp_ajax_check_chapter_import_status', array(__CLASS__, 'ajax_check_chapter_import_status'));
        
        // Add admin notices for completed imports
        add_action('admin_notices', array(__CLASS__, 'display_import_notices'));
    }
    
    /**
     * Track a chapter as part of a manga import
     * 
     * @param string $manga_hash The manga import hash
     * @param string $chapter_url The chapter URL
     * @param string $chapter_hash The chapter hash
     * @return bool Success
     */
    public static function track_chapter_in_manga($manga_hash, $chapter_url, $chapter_hash) {
        $log_key = 'manga_importer_log_' . $manga_hash;
        $current = get_option($log_key, array());
        
        if (empty($current)) {
            return false;
        }
        
        // Initialize chapters array if it doesn't exist
        if (!isset($current['chapters'])) {
            $current['chapters'] = array();
        }
        
        // Add chapter to tracking
        $current['chapters'][$chapter_url] = array(
            'hash' => $chapter_hash,
            'status' => 'pending',
            'added_at' => current_time('mysql')
        );
        
        return update_option($log_key, $current);
    }
    
    /**
     * Update chapter status within a manga import
     * 
     * @param string $manga_hash The manga import hash
     * @param string $chapter_url The chapter URL
     * @param string $status The chapter status (pending, processing, completed, failed)
     * @return bool Success
     */
    public static function update_chapter_in_manga($manga_hash, $chapter_url, $status) {
        $log_key = 'manga_importer_log_' . $manga_hash;
        $current = get_option($log_key, array());
        
        if (empty($current) || !isset($current['chapters']) || !isset($current['chapters'][$chapter_url])) {
            return false;
        }
        
        // Update chapter status
        $current['chapters'][$chapter_url]['status'] = $status;
        
        if ($status === 'completed') {
            $current['chapters'][$chapter_url]['completed_at'] = current_time('mysql');
        } elseif ($status === 'failed') {
            $current['chapters'][$chapter_url]['failed_at'] = current_time('mysql');
        }
        
        return update_option($log_key, $current);
    }
    
    /**
     * Get all chapters for a manga import
     * 
     * @param string $manga_hash The manga import hash
     * @return array|false Chapters array or false if not found
     */
    public static function get_manga_chapters($manga_hash) {
        $log_key = 'manga_importer_log_' . $manga_hash;
        $current = get_option($log_key, array());
        
        if (empty($current) || !isset($current['chapters'])) {
            return false;
        }
        
        return $current['chapters'];
    }
    
    /**
     * Create a new import status entry
     *
     * @param string $type Either 'manga' or 'chapter'
     * @param string $url The URL being imported
     * @param array $data Additional data to store
     * @return string The status key (hash)
     */
    public static function create_status($type, $url, $data = array()) {
        $hash = md5($url);
        $log_key = $type . '_importer_log_' . $hash;
        
        $status_data = array_merge(array(
            'output' => '',
            'status' => 'processing',
            'started_at' => current_time('mysql'),
            'url' => $url,
        ), $data);
        
        update_option($log_key, $status_data);
        
        return $hash;
    }
    
    /**
     * Update an existing import status
     *
     * @param string $type Either 'manga' or 'chapter'
     * @param string $hash The status hash
     * @param array $data Data to update
     * @return bool Success
     */
    public static function update_status($type, $hash, $data) {
        $log_key = $type . '_importer_log_' . $hash;
        $current = get_option($log_key, array());
        
        if (empty($current)) {
            return false;
        }
        
        $updated = array_merge($current, $data);
        return update_option($log_key, $updated);
    }
    
    /**
     * Get status data
     *
     * @param string $hash The status hash
     * @return array|false Status data or false if not found
     */
    public static function get_status($hash) {
        // Try manga first
        $log_key = 'manga_importer_log_' . $hash;
        $log = get_option($log_key);
        
        if (!$log) {
            // Try chapter
            $log_key = 'chapter_importer_log_' . $hash;
            $log = get_option($log_key);
        }
        
        return $log;
    }
    
    /**
     * AJAX handler for checking manga import status
     */
    public static function ajax_check_manga_import_status() {
        // Verify nonce
        if (!isset($_REQUEST['nonce']) || !wp_verify_nonce($_REQUEST['nonce'], 'manga_importer_status')) {
            wp_send_json_error('Invalid security token');
        }
        
        if (!isset($_REQUEST['hash'])) {
            wp_send_json_error('Missing hash parameter');
        }
        
        $hash = sanitize_text_field($_REQUEST['hash']);
        $log_key = 'manga_importer_log_' . $hash;
        $log = get_option($log_key);
        
        if (!$log) {
            wp_send_json_error('Status not found');
        }
        
        wp_send_json_success($log);
    }
    
    /**
     * AJAX handler for checking chapter import status
     */
    public static function ajax_check_chapter_import_status() {
        // Verify nonce
        if (!isset($_REQUEST['nonce']) || !wp_verify_nonce($_REQUEST['nonce'], 'manga_importer_status')) {
            wp_send_json_error('Invalid security token');
        }
        
        if (!isset($_REQUEST['hash'])) {
            wp_send_json_error('Missing hash parameter');
        }
        
        $hash = sanitize_text_field($_REQUEST['hash']);
        $log_key = 'chapter_importer_log_' . $hash;
        $log = get_option($log_key);
        
        if (!$log) {
            wp_send_json_error('Status not found');
        }
        
        wp_send_json_success($log);
    }
    
    /**
     * Display admin notices for completed imports
     */
    public static function display_import_notices() {
        // Only show on our admin page
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'toplevel_page_the-importer-by-ma3och') {
            return;
        }
        
        // Don't show on status page
        if (isset($_GET['view_status'])) {
            return;
        }
        
        // Check for recently completed imports
        $completed_imports = self::get_recent_completed_imports();
        
        // Check for pending imports that need approval
        $pending_imports = self::get_pending_imports();
        
        // Display pending imports first
        if (!empty($pending_imports)) {
            foreach ($pending_imports as $import) {
                $hash = str_replace('manga_importer_log_', '', $import['key']);
                
                echo '<div class="notice notice-warning is-dismissible"><p>';
                echo '<strong>Manga import pending approval!</strong> ';
                echo 'Similar titles found for "' . esc_html($import['data']['manga_data']['title']) . '". ';
                echo '<a href="' . admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash) . '" class="button button-small">Review</a>';
                echo '</p></div>';
            }
        }
        
        // Display completed imports
        if (!empty($completed_imports)) {
            foreach ($completed_imports as $import) {
                $type = strpos($import['key'], 'manga_importer_log_') === 0 ? 'manga' : 'chapter';
                $hash = str_replace(array('manga_importer_log_', 'chapter_importer_log_'), '', $import['key']);
                
                echo '<div class="notice notice-success is-dismissible"><p>';
                if ($type === 'manga') {
                    echo 'Manga import completed! ';
                    if (isset($import['data']['manga_id'])) {
                        echo '<a href="' . get_edit_post_link($import['data']['manga_id']) . '">View Manga</a> | ';
                    }
                } else {
                    echo 'Chapter import completed! ';
                    if (isset($import['data']['manga_id'])) {
                        echo '<a href="' . get_edit_post_link($import['data']['manga_id']) . '">View Manga</a> | ';
                    }
                }
                echo '<a href="' . admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash) . '">View Details</a>';
                echo '</p></div>';
                
                // Mark as seen
                $import['data']['notice_shown'] = true;
                update_option($import['key'], $import['data']);
            }
        }
    }
    
    /**
     * Get recently completed imports that haven't had notices shown
     *
     * @return array Array of completed imports
     */
    private static function get_recent_completed_imports() {
        global $wpdb;
        
        $completed = array();
        
        // Get all options that match our log keys
        $manga_options = $wpdb->get_results(
            "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'manga_importer_log_%' OR option_name LIKE 'chapter_importer_log_%'"
        );
        
        if (!empty($manga_options)) {
            foreach ($manga_options as $option) {
                $data = maybe_unserialize($option->option_value);
                
                // Check if it's completed and notice hasn't been shown
                if (isset($data['status']) && $data['status'] === 'completed' && empty($data['notice_shown'])) {
                    $completed[] = array(
                        'key' => $option->option_name,
                        'data' => $data
                    );
                }
            }
        }
        
        return $completed;
    }
    
    /**
     * Get pending imports that need approval
     *
     * @return array Array of pending imports
     */
    private static function get_pending_imports() {
        global $wpdb;
        
        $pending = array();
        
        // Get all options that match our manga log keys
        $manga_options = $wpdb->get_results(
            "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'manga_importer_log_%'"
        );
        
        foreach ($manga_options as $option) {
            $data = maybe_unserialize($option->option_value);
            
            // Check if this is a pending import
            if (isset($data['status']) && $data['status'] === 'pending') {
                $pending[] = array(
                    'key' => $option->option_name,
                    'data' => $data
                );
            }
        }
        
        return $pending;
    }
}

// Initialize the class
Manga_Importer_Status::init();