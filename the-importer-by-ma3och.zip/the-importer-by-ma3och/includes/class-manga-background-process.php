<?php
/**
 * Background Processing for Manga Importer
 *
 * @package The_Importer_By_Kimo
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include WP Background Processing library if not already included
if (!class_exists('WP_Background_Process', false)) {
    if (file_exists(WP_PLUGIN_DIR . '/woocommerce/includes/libraries/wp-background-process.php')) {
        // Use WooCommerce's version if available
        require_once WP_PLUGIN_DIR . '/woocommerce/includes/libraries/wp-async-request.php';
        require_once WP_PLUGIN_DIR . '/woocommerce/includes/libraries/wp-background-process.php';
    } else {
        // Download and include the library if not available
        // This should be handled during plugin activation in a real-world scenario
        wp_die('Required library WP Background Processing not found. Please install WooCommerce or manually add the library.');
    }
}

/**
 * Manga Background Process Class
 * Handles background processing for manga imports
 */
class Manga_Background_Process extends WP_Background_Process {

    /**
     * Action prefix
     *
     * @var string
     */
    protected $prefix = 'manga_importer';

    /**
     * Action name
     *
     * @var string
     */
    protected $action = 'process_manga';

    /**
     * Task
     *
     * Override this method to perform actions on each item in the queue
     *
     * @param mixed $item Queue item to process
     * @return mixed
     */
    protected function task($item) {
        // Process manga import
        if (isset($item['manga_url'])) {
            $url = $item['manga_url'];
            $chapter_limit = isset($item['chapter_limit']) ? $item['chapter_limit'] : null;
            $hash = isset($item['hash']) ? $item['hash'] : md5($url);
            $force_import = isset($item['force_import']) ? $item['force_import'] : false;
            
            // Check if this manga was already processed
            $status = Manga_Importer_Status::get_status($hash);
            if ($status && isset($status['status']) && $status['status'] === 'completed') {
                // This manga was already successfully imported, skip it
                return false; // Remove from queue
            }
            
            // Update status to processing if not already set
            if (!$status || !isset($status['status']) || ($status['status'] !== 'processing' && $status['status'] !== 'pending')) {
                Manga_Importer_Status::update_status('manga', $hash, [
                    'status' => 'processing',
                    'manga_url' => $url,
                    'chapter_limit' => $chapter_limit,
                    'processing_started' => current_time('mysql')
                ]);
            }
            
            // Store the current output buffer
            ob_start();
            
            try {
                // Import the manga
                $manga_id = the_importer_by_kimo_import_manga_bg($url, $chapter_limit, $hash, $force_import);
                
                // Get the output
                $output = ob_get_clean();
                
                // If manga_id is null, it means the import is pending approval
                if ($manga_id === null) {
                    // Status was already updated in the import function
                    return false; // Remove from queue
                }
                
                // Update the status using the status handler
                Manga_Importer_Status::update_status('manga', $hash, [
                    'output' => $output,
                    'status' => 'completed',
                    'manga_id' => $manga_id,
                    'completed_at' => current_time('mysql')
                ]);
            } catch (Exception $e) {
                // Catch any exceptions to prevent the entire queue from failing
                $output = ob_get_clean();
                $output .= '\nError: ' . $e->getMessage();
                
                // Update status to failed
                Manga_Importer_Status::update_status('manga', $hash, [
                    'output' => $output,
                    'status' => 'failed',
                    'error' => $e->getMessage(),
                    'manga_url' => $url,
                    'chapter_limit' => $chapter_limit,
                    'failed_at' => current_time('mysql')
                ]);
            }
        }
        
        return false; // Remove from queue
    }

    /**
     * Complete
     *
     * Override if applicable, but ensure that the below actions are
     * performed, or, call parent::complete().
     */
    protected function complete() {
        parent::complete();
        
        // Maybe update a global status or trigger notifications
        update_option('manga_importer_last_run', current_time('mysql'));
        do_action('manga_importer_process_complete');
    }
}

/**
 * Chapter Background Process Class
 * Handles background processing for chapter imports
 */
class Chapter_Background_Process extends WP_Background_Process {

    /**
     * Action prefix
     *
     * @var string
     */
    protected $prefix = 'manga_importer';

    /**
     * Action name
     *
     * @var string
     */
    protected $action = 'process_chapter';

    /**
     * Task
     *
     * Override this method to perform actions on each item in the queue
     *
     * @param mixed $item Queue item to process
     * @return mixed
     */
    protected function task($item) {
        // Process chapter import
        if (isset($item['chapter_url']) && isset($item['manga_id'])) {
            $chapter_url = $item['chapter_url'];
            $manga_id = $item['manga_id'];
            $hash = isset($item['hash']) ? $item['hash'] : md5($chapter_url);
            
            // Check if this chapter was already processed
            $status = Manga_Importer_Status::get_status($hash);
            if ($status && isset($status['status']) && $status['status'] === 'completed') {
                // This chapter was already successfully imported, skip it
                return false; // Remove from queue
            }
            
            // Update status to processing if not already set
            if (!$status || !isset($status['status']) || $status['status'] !== 'processing') {
                Manga_Importer_Status::update_status('chapter', $hash, [
                    'status' => 'processing',
                    'manga_id' => $manga_id,
                    'chapter_url' => $chapter_url,
                    'processing_started' => current_time('mysql')
                ]);
            }
            
            // Store the current output buffer
            ob_start();
            
            try {
                // Import the chapter
                $result = the_importer_by_kimo_import_chapter_bg($chapter_url, $manga_id);
                
                // Get the output
                $output = ob_get_clean();
                
                // Update the status using the status handler
                Manga_Importer_Status::update_status('chapter', $hash, [
                    'output' => $output,
                    'status' => 'completed',
                    'manga_id' => $manga_id,
                    'chapter_url' => $chapter_url,
                    'completed_at' => current_time('mysql')
                ]);
            } catch (Exception $e) {
                // Catch any exceptions to prevent the entire queue from failing
                $output = ob_get_clean();
                $output .= '\nError: ' . $e->getMessage();
                
                // Update status to failed
                Manga_Importer_Status::update_status('chapter', $hash, [
                    'output' => $output,
                    'status' => 'failed',
                    'error' => $e->getMessage(),
                    'manga_id' => $manga_id,
                    'chapter_url' => $chapter_url,
                    'failed_at' => current_time('mysql')
                ]);
            }
        }
        
        return false; // Remove from queue
    }

    /**
     * Complete
     *
     * Override if applicable, but ensure that the below actions are
     * performed, or, call parent::complete().
     */
    protected function complete() {
        parent::complete();
        
        // Maybe update a global status or trigger notifications
        update_option('chapter_importer_last_run', current_time('mysql'));
        do_action('chapter_importer_process_complete');
    }
}