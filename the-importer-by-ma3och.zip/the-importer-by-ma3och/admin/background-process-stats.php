<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function the_importer_by_kimo_stats_page() {
    global $wpdb;
    
    // Get all import logs
    $manga_logs = $wpdb->get_results(
        "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'manga_importer_log_%'"
    );
    $chapter_logs = $wpdb->get_results(
        "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'chapter_importer_log_%'"
    );
    
    // Process stats
    $stats = array(
        'manga' => array(
            'total' => 0,
            'processing' => 0,
            'completed' => 0,
            'failed' => 0
        ),
        'chapter' => array(
            'total' => 0,
            'processing' => 0,
            'completed' => 0,
            'failed' => 0
        )
    );
    
    // Process manga logs
    foreach ($manga_logs as $log) {
        $data = maybe_unserialize($log->option_value);
        $stats['manga']['total']++;
        if ($data['status'] === 'processing') {
            $stats['manga']['processing']++;
        } elseif ($data['status'] === 'completed') {
            $stats['manga']['completed']++;
        } else {
            $stats['manga']['failed']++;
        }
    }
    
    // Process chapter logs
    foreach ($chapter_logs as $log) {
        $data = maybe_unserialize($log->option_value);
        $stats['chapter']['total']++;
        if ($data['status'] === 'processing') {
            $stats['chapter']['processing']++;
        } elseif ($data['status'] === 'completed') {
            $stats['chapter']['completed']++;
        } else {
            $stats['chapter']['failed']++;
        }
    }
    
    // Display stats
    ?>
    <div class="wrap">
        <h1>Background Processing Statistics</h1>
        
        <div class="card" style="max-width: 100%;">
            <h2>Manga Import Stats</h2>
            <table class="widefat">
                <tr>
                    <th>Total Imports</th>
                    <td><?php echo $stats['manga']['total']; ?></td>
                </tr>
                <tr>
                    <th>Processing</th>
                    <td><?php echo $stats['manga']['processing']; ?></td>
                </tr>
                <tr>
                    <th>Completed</th>
                    <td><?php echo $stats['manga']['completed']; ?></td>
                </tr>
                <tr>
                    <th>Failed</th>
                    <td><?php echo $stats['manga']['failed']; ?></td>
                </tr>
            </table>
        </div>
        
        <div class="card" style="max-width: 100%; margin-top: 20px;">
            <h2>Chapter Import Stats</h2>
            <table class="widefat">
                <tr>
                    <th>Total Imports</th>
                    <td><?php echo $stats['chapter']['total']; ?></td>
                </tr>
                <tr>
                    <th>Processing</th>
                    <td><?php echo $stats['chapter']['processing']; ?></td>
                </tr>
                <tr>
                    <th>Completed</th>
                    <td><?php echo $stats['chapter']['completed']; ?></td>
                </tr>
                <tr>
                    <th>Failed</th>
                    <td><?php echo $stats['chapter']['failed']; ?></td>
                </tr>
            </table>
        </div>
        
        <div class="card" style="max-width: 100%; margin-top: 20px;">
            <h2>Recent Imports</h2>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>URL</th>
                        <th>Status</th>
                        <th>Started</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent_imports = array_merge($manga_logs, $chapter_logs);
                    usort($recent_imports, function($a, $b) {
                        $a_data = maybe_unserialize($a->option_value);
                        $b_data = maybe_unserialize($b->option_value);
                        return strtotime($b_data['started_at']) - strtotime($a_data['started_at']);
                    });
                    
                    $recent_imports = array_slice($recent_imports, 0, 10); // Show last 10 imports
                    
                    foreach ($recent_imports as $import) {
                        $data = maybe_unserialize($import->option_value);
                        $type = strpos($import->option_name, 'manga_importer_log_') === 0 ? 'Manga' : 'Chapter';
                        $hash = str_replace(array('manga_importer_log_', 'chapter_importer_log_'), '', $import->option_name);
                        ?>
                        <tr>
                            <td><?php echo esc_html($type); ?></td>
                            <td><?php echo esc_html($data['url']); ?></td>
                            <td><?php echo esc_html(ucfirst($data['status'])); ?></td>
                            <td><?php echo esc_html(human_time_diff(strtotime($data['started_at']), current_time('timestamp'))); ?> ago</td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=the-importer-by-ma3och&view_status=' . $hash); ?>" class="button button-small">View Details</a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}